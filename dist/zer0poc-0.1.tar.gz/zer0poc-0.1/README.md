# 0PoC
<<<<<<< HEAD
PoC generater for fast and pretty for your vulnerabilty.
=======
PoC generater for fast and pretty for your vulnerabilty.
>>>>>>> 1073131fe33f5b9fc85c82bebc7eff550b0f4896
